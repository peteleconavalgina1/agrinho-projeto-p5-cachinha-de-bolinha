function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let truck;
let pedestrians = [];
let score = 0;
let gameOver = false;

function setup() {
  createCanvas(600, 400);
  truck = new Truck();
}

function draw() {
  background(220);

  if (gameOver) {
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text('Fim de Jogo!', width / 2, height / 2);
    textSize(16);
    text('Pressione F5 para reiniciar', width / 2, height / 2 + 40);
    return;
  }

  truck.update();
  truck.display();

  if (frameCount % 60 === 0) {
    pedestrians.push(new Pedestrian());
  }

  for (let i = pedestrians.length - 1; i >= 0; i--) {
    pedestrians[i].update();
    pedestrians[i].display();

    if (pedestrians[i].hits(truck)) {
      gameOver = true;
    }

    if (pedestrians[i].offscreen()) {
      pedestrians.splice(i, 1);
      score++;
    }
  }

  displayScore();
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    truck.setDir(-1);
  } else if (keyCode === RIGHT_ARROW) {
    truck.setDir(1);
  }
}

function keyReleased() {
  if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW) {
    truck.setDir(0);
  }
}

function displayScore() {
  textSize(16);
  fill(0);
  text('Pontuação: ' + score, 10, 20);
}

class Truck {
  constructor() {
    this.x = width / 2;
    this.y = height - 30;
    this.size = 30;
    this.speed = 5;
    this.dir = 0;
  }

  setDir(dir) {
    this.dir = dir;
  }

  update() {
    this.x += this.dir * this.speed;
    this.x = constrain(this.x, 0, width - this.size);
  }

  display() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.size, this.size);
  }
}

class Pedestrian {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 20;
    this.speed = random(2, 5);
  }

  update() {
    this.y += this.speed;
  }

  display() {
    fill(0, 0, 255);
    ellipse(this.x, this.y, this.size);
  }

  offscreen() {
    return this.y > height;
  }

  hits(truck) {
    return (
      this.x > truck.x &&
      this.x < truck.x + truck.size &&
      this.y > truck.y &&
      this.y < truck.y + truck.size
    );
  }
}